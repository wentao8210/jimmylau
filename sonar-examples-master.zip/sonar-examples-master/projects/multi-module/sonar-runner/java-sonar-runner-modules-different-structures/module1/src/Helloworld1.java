public class Helloworld1 {

  public void printHelloWorld1() {
    System.out.println("Hello World 1!");
  }
  
}

