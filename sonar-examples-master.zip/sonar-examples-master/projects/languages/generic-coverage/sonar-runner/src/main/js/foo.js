function process() {
	if (i > 3) {
		return i;
	}
	return 0;
}
