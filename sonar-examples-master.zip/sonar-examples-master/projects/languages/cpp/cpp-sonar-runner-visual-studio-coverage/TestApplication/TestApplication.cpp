// TestApplication.cpp : Defines the entry point for the console application.
//

int positive(int a) {
  if (a > 0) {
    return 1;
  } else {
    return 0;
  }
}

int main(int argc, char* argv[]) {
  int c = 0;
  if (argc == 1) {
    c = 1;
  } else if (argc == 1) {
    c = 2;
  }
  else {
  }
	return 0;
}

